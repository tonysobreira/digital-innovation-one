package one.digitalinnovation.interfaces;

public interface Automovel {

}
