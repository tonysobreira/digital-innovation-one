export class Post{
  
  public id: number
  public nome: string
  public mensagem: string

}