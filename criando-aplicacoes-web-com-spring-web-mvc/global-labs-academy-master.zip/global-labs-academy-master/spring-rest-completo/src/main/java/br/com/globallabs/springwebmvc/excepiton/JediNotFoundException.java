package br.com.globallabs.springwebmvc.excepiton;

public class JediNotFoundException extends RuntimeException {

}
